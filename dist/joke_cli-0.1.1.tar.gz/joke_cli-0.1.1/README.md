# joke_cli

joke_cli is a CLI that fetches and prints random jokes from various free joke APIs.

## Installation

>Requires Python 3.0 or higher

`pip install joke-cli`

## Usage

